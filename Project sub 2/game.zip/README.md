# Animal-Guessing-Game-in-C
The user thinks of an animal and the program attempts to guess what that animal is. The program communicates with the user through  standard input and standard output (stdio.h). 

# This project combines the following topics together: 
## • Pointers and linked lists 
## • Structs 
## • File I/O 
## • Recursion 
