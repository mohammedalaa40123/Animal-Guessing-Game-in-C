#ifndef NODE_H
#define NODE_H  
struct node {
	char data[100];
	struct node* yes;
	struct node* no;
};
typedef struct node node;
typedef struct node node;
#endif